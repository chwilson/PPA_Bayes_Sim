library(mvtnorm)   # to draw multivariate normal outcomes
library(raster)    # to plot stuff
library(rasterVis) # to plot fancy stuff
library(ggplot2)   # more fancy plots

### Functions from Petr Keil 
# function that makes distance matrix for a side*side 2D array  
dist.matrix <- function(side)
{
  row.coords <- rep(1:side, times=side)
  col.coords <- rep(1:side, each=side)
  row.col <- data.frame(row.coords, col.coords)
  D <- dist(row.col, method="euclidean", diag=TRUE, upper=TRUE)
  D <- as.matrix(D)
  return(D)
}

# function that simulates the autocorrelated 2D array with a given side,
# and with exponential decay given by lambda
# (the mean mu is constant over the array, it equals to global.mu)
cor.surface <- function(side, global.mu, lambda)
{
  D <- dist.matrix(side)
  # scaling the distance matrix by the exponential decay
  SIGMA <- exp(-lambda*D)
  mu <- rep(global.mu, times=side*side)
  # sampling from the multivariate normal distribution
  M <- matrix(nrow=side, ncol=side)
  M[] <- rmvnorm(1, mu, SIGMA)
  return(M)
}


side= 30  # sides of the raster
distMat <- dist.matrix(side)
distMat[1:10,1:10]

str(distMat)
# Fix output from arbitrary pixel, the distance from that pixel to any other pixel 
# is given by that row 
out1 <- 10^5

seed_input <- Alt2Dt2(distMat[465,],a=2,b=2)

sum(seed_input) # So this definitely does not obey probability 
seed_inputNormalized <- seed_input/sum(seed_input)
seed_inputMat <- matrix(out1*seed_inputNormalized,nrow = 10, ncol = 10)

levelplot(seed_inputMat)


## OK, now I need to have output from all cells dispersing into 



### Generated autocorrelated matrices (useful for later)
global.mu=0 # mean of the process

M.01    <- cor.surface(side=side, lambda=0.01, global.mu=global.mu)
M.1     <- cor.surface(side=side, lambda=0.1, global.mu=global.mu)
M1      <- cor.surface(side=side, lambda=1, global.mu=global.mu)
M.white <-matrix(rnorm(side*side), nrow=side, ncol=side)

M.list <- list(my.rast(M.01, max.ext=side), 
               my.rast(M.1, max.ext=side), 
               my.rast(M1, max.ext=side), 
               my.rast(M.white, max.ext=side))
MM <- stack(M.list)
names(MM) <- c("Lambda_0.01", "Lambda_0.1", "Lambda_1", "White_noise")

levelplot(MM) # fancy plot from the rasterVis package




# function that converts a matrix to raster and scales its sides to max.ext
my.rast <- function(mat, max.ext)
{
  rast <- raster(mat)
  rast@extent@xmax <- max.ext
  rast@extent@ymax <- max.ext
  return(rast)
}


Clark2Dt <- function(x,u){
  p<-1;
  disp <- 2*pi*x*(p/(3.141593*u))/((1+(x^2/u))^(p+1));
  return(disp);
}



# Dispersal distance kernel
Alt2Dt <- function(x,a,b,s=1){
  disp <- s*2*pi*x*((b-1)/(pi*a^2))*(1 +(x^2/a^2))^-b;
  return(disp);
} # sums to 1

# Dispersal location kernel
Alt2Dt2 <- function(x,a,b,Q=1){
  disp <- Q*((b-1)/(pi*a^2))*(1 +(x^2/a^2))^-b;
  return(disp);
} # does not sum to 1 


Alt2Dt2_NDD <- function(x,a,b,k){
  disp <- (1/(1+((1/0.01)-1)*exp(-k*x)))*((b-1)/(pi*a^2))*(1 +(x^2/a^2))^-b;
  return(disp);
} #
integrate(Alt2Dt2_NDD, 0, 20, a = 2, b=2, k= 2)



Alt2Dt_NDD <- function(x,a,b,k){
  disp <- (2*pi*x)*(1/(1+((1/0.01)-1)*exp(-k*x)))*((b-1)/(pi*a^2))*(1 +(x^2/a^2))^-b;
  return(disp);
} 

a <- 2
b <- 2
curve((1/(1+((1/0.01)-1)*exp(-4*x))),0,5)
curve(Alt2Dt2(x,a=2,b=2),0,5)

## Panel 1 Density and Survivorship 
Density_Survivor <- ggplot(data.frame(x=c(0,10)), aes(x)) + 
  stat_function(fun = Alt2Dt2, args = list(a=2,b=1.1,Q = 10^2)) +
  stat_function(fun = function(x){(1/(1+((1/0.01)-1)*exp(-3*x)))}) +
  ylab("Density (Seeds/Area or Survival)") + xlab("radial distance")


## Panel 2 comparing JC effect from just NDD to the area correction
Area_JC <- ggplot(data.frame(x = c(0,10)),aes(x)) + 
  stat_function(fun = Alt2Dt2_NDD, args = list(a=2,b=1.1,k=3)) +
  stat_function(fun = Alt2Dt, args = list(a=2,b=1.1,s=0.1),color = "blue") +
  ylab("Location Expectation (blue) versus NDD J-C effect") +
  xlab("radial distance")

library(cowplot)
plot_grid(Density_Survivor, Area_JC)

### These kernels are related by 2*pi*x in 2D
library(ggplot2)
#ggplot(data.frame(x = c(0,100)),aes(x)) + stat_function(fun = Clark2Dt, args = list(u = 4))
ggplot(data.frame(x = c(0,10)),aes(x)) + stat_function(fun = Alt2Dt2, args = list(a = 2, b = 2)) +
  stat_function(fun = Alt2Dt, args = list(a = 2, b = 2), color = "red") +
  stat_function(fun = Alt2Dt2_NDD, args = list(a=2,b=2,k=0.5), color = "blue")



integrate(Alt2Dt,0,20,a=2,b=2)


